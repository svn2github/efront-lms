vti_encoding:SR|utf8
vti_extenderversion:SR|2.0.1.928
vti_author:SR|
vti_modifiedby:SR|
vti_timecreated:TR|27 Nov 1996 18:39:19 +0200
vti_timelastmodified:TR|27 Nov 1996 18:39:19 +0200
