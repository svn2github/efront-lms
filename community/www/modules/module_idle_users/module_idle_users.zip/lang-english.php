<?php 
define("_MODULE_IDLE_USERS_IDLEUSERS", "Idle users");
define("_MODULE_IDLE_USERS_LASTACTION", "Last action");
define("_MODULE_IDLE_USERS_SHOWINACTIVEUSERSSINCE", "Show users idle since");
define("_MODULE_IDLE_USERS_ARCHIVEALLUSERS", "Archive all users");
define("_MODULE_IDLE_USERS_THISWILLARCHIVEALLUSERSAREYOUSURE", "This will archive all users returned matching the selected criteria! Are you sure?");
define("_MODULE_IDLE_USERS_DEACTIVATEALLUSERS", "Deactivate all users");
define("_MODULE_IDLE_USERS_THISWILLDEACTIVATEALLUSERSAREYOUSURE", "This will deactivate all users returned matching the selected criteria! Are you sure?");
define("_MODULE_IDLE_USERS_TOGGLESTATUS", "Toggle status");
define("_MODULE_IDLE_USERS_LAST3MONTHS", "Last 3 months");
define("_MODULE_IDLE_USERS_OTHEROPTIONS", "Other options");
define("_MODULE_IDLE_USERS_LASTACTIONSINCE", "Last action since");